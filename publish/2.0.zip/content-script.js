chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	if (request.command === "start") {
		let scrollPosition = 0;
		let screenHeight = window.innerHeight;
		let totalHeight = document.documentElement.scrollHeight;
		let screenshotList = [];

		// 最大スクロールピクセル数を設定する
		const maxScrollPixels = 20000;

		async function scrollAndCapture() {
			if (scrollPosition >= totalHeight || scrollPosition >= maxScrollPixels) {
				// スクロールが完了したら、screenshotListをpopup.jsに送信する
				console.log(screenshotList);
				chrome.runtime.sendMessage({ command: "screenshotList", data: screenshotList, inputUrl: window.location.href }, function (response) {
					console.log(response);
				});

				return;
			}

			// スクロールする
			window.scrollTo(0, scrollPosition);

			// スクリーンショットを取得する
			const response = await new Promise(resolve => {
				chrome.runtime.sendMessage({ command: "capture" }, function (response) {
					resolve(response);
				});
			});
			screenshotList.push(response.dataURL);

			// スクロール位置を更新する
			scrollPosition += screenHeight / 3;

			// 次のスクロールとスクリーンショットを実行する
			setTimeout(scrollAndCapture, 500);
		}

		// スクロールとスクリーンショットの処理を開始する
		scrollAndCapture();
	}
});


chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	if (request.command === "capture") {
		// スクリーンショットを取得する
		chrome.tabs.captureVisibleTab(null, { format: "png" }, function (dataURL) {
			sendResponse({ dataURL: dataURL });
		});
		// 非同期処理であるため、trueを返してレスポンスが返るまで待機する
		return true;
	}
});
